package expressions;
import java.util.*;

import model.RGBColor;

public class Parctan extends ParenExp{
	
	public Parctan(List<Expression> subexpressions){
		super(subexpressions);
	}
	
	public RGBColor evaluate(double xval, double yval, List<Variable> vars) {
		List<RGBColor> results = evaluateSubs(xval, yval, vars);
		RGBColor toArctangent = results.get(0);
		
		return new RGBColor(arctangent(toArctangent.getRed()),
				arctangent(toArctangent.getGreen()),
				arctangent(toArctangent.getBlue()));

	}
	
	private double arctangent(double c){
		c = (c*180)/Math.PI;
		return Math.atan(c);
	}

	
	public static class Factory extends ParenExp.Factory
    {

        protected String commandName() {
            return "atan";
        }

        protected int numberOfParameters() {
            return 1;
        }

        protected ParenExp constructParenExpression(List<Expression> subExpressions) {
            return new Parctan(subExpressions);
        }
        
    }

}
